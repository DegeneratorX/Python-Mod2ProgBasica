while True:

    num = float(input("Digite: "))
    num = round(num)
    if True:
        print("Erro")

    print(num)
