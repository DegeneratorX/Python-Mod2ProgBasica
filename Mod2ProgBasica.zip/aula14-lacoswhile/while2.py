"""
While
"""

x = 0 # coluna

while x < 10:
    y = 0  # linha
    
    while y < 5:
        print(f"x vale {x} e y vale {y}.")
        y += 1

    x += 1 # x = x + 1
