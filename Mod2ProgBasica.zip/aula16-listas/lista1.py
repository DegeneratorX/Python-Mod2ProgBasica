"""
Listas
fatiamento
append, insert, pop, del, clear, etend, +
min, max
range
"""

texto = "Valor"
listaExemplo = [1, 2, 3, 4, "Victor", True, 10.5]  # É como se fosse uma variável com vários valores dentro dela
print(listaExemplo)  # Printa a lista toda.

#############################################

#         0    1    2    3    4
lista = ["A", "B", "C", "D", "E"]
#      -  5    4    3    2    1

string = "ABCDE"

print(string[1])  # Acessa o índice (caractere) da string.
print(lista[1])  # Acessa o índice (caractere) da lista.

# A diferença é que na lista, você consegue pegar até palavras. Exemplo:

listaPalavras = ["Lab", "Python", "Olá"]
print(listaPalavras[1])  # Printará "Phyton".


