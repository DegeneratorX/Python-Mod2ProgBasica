"""
Listas
fatiamento [começo:até quanto:passos]
append, insert, pop, del, clear, extend, +
min, max
range
"""

l1 = ['String', True, 10, -20.5]
 
for elemento in l1:
    print(f'O tipo de elemento é {type(elemento)} e seu valor é {elemento}')
