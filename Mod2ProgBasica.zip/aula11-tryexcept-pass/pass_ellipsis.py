valor = True

if valor:
    pass
else:
    print("Falso")

if valor:
    ...  # ellipsis
else:
    print("Falso")

# Se deixar o if vazio, ocorrerá um erro. Portanto, as vezes
# é necessário deixar com pass o ... para que o python ignore.


