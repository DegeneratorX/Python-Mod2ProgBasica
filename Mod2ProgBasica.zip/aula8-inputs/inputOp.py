"""Operações"""

numero_1 = input('Digite um número: ')
numero_2 = input('Digite outro número: ')

print(numero_1 + numero_2)  # na verdade concatena as strings digitadas


print('Agora isso irá de fato somar.')
numero_1 = int(input('Digite um número: '))
numero_2 = input('Digite outro número: ')
numero_2 = int(numero_2)  # outra forma de converter pra int

print(numero_1+numero_2)
