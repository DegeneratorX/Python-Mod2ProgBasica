x = "10"
for y in x:
    print(y)

