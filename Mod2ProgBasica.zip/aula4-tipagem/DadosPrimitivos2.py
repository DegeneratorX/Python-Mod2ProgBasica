# Nome: str
print('Victor Martins', type('Victor Martins'))

# Idade: int
print(25, type(25))

# Altura: float
print(1.85, type(1.85))

# É maior de idade x>18
print(32>18, type(32>18))