"""
Programa que pede o usuário um número inteiro. Verifica se é par ou impar,
se não for um inteiro, informar que não é.
"""

num = input("Digite um número inteiro: ")

try:
    num = int(num)

except:
    print("Erro: o dígito não é um número.")
    exit()

if num % 2 == 0:
    print(f"O número {num} é par.")
else:
    print(f"O número {num} é ímpar.")
