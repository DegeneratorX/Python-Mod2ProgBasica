"""Pergunta a hora, exibe saudação de acordo com horário"""

hora = input("Digite a hora (entre 0 e 23): ")

try:
    hora = int(hora)
except:
    print("Erro: digito inválido.")
    exit()

if hora >= 0 and hora <= 11:
    print("Bom dia!")
elif hora >= 12 and hora <= 17:
    print("Boa tarde!")
elif hora >= 18 and hora <= 23:
    print("Boa noite!")
else:
    print("Horário inválido")
