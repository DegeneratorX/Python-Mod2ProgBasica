"""Programa que pede o primeiro nome e solicita condições para o nome."""

nome = input("Digite o seu primeiro nome: ")
tamanho = len(nome)

if not nome.isnumeric():
    if tamanho <= 4:
        print("Seu nome é curto")
    elif tamanho <= 6:
        print("Seu nome é normal")
    else:
        print("Seu nome é grande.")
else:
    print("Erro: seu nome é um número.")
