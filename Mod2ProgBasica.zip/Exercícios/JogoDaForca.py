palavra = "tryndamere"
lista = []
chances = 3

while True:

    if chances == 0:
        print("Você perdeu. Chances restantes zero.")
        break

    digito = input("Digite uma letra: ")

    if len(digito) > 1 or digito.isdigit():
        print("Erro: você digitou um bagulho nada a ver.")
        continue

    lista.append(digito)

    if digito in palavra:
        print(f"O dígito {digito} está na palavra.")
    else:
        chances -= 1
        print(f"O dígito {digito} NÃO está na palavra. Chances restantes: {chances}")
        lista.pop()

    string_temp = ""

    for letra in palavra:
        if letra in lista:
            string_temp += letra
        else:
            string_temp += "*"

    if string_temp == palavra:
        print(f"Você achou a palavra: {string_temp}")
        break
    else:
        print(f'A palavra está assim: {string_temp}')
