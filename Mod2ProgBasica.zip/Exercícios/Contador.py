cont1 = 0
cont2 = 10

for valor in range(cont1, 9):
    print(valor, cont2)
    cont2 -= 1
