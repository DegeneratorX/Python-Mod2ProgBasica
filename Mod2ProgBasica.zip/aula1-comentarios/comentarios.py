print('Linha 1')
'''print('Linha 2')'''
# Comentário exemplo
"""print('Linha 3')
print('Linha 4')
print('Linha 5')"""  # Outro comentário exemplo
print('Linha 6')

print('ola mundo')  #print