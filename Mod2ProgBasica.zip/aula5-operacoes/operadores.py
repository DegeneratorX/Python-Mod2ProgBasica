"""
+,-,*,/

// divisão inteira (arredonda)
** exponenciação (potenciação)
% resto da divisão (módulo)
() parênteses de prioridades
"""

print('Multiplicação', 10 * 10)
print('Adição', 10 + 10)
print('Subtração', 10 - 5)
print('Divisão', 10 / 2)

print('Multiplicação especial', 5 * '10')  # repete a string "10" cinco vezes.
print('Adição especial', '5' + '10')  # Junta a string 5 com 10, formando a string 510.

print('Divisão inteira', 10//3)
print('Divisão inteira', 11.2//3)  # Nesse caso retorna um float, pois existe um float na expresão.

print('\nExponenciação', 3**3)
